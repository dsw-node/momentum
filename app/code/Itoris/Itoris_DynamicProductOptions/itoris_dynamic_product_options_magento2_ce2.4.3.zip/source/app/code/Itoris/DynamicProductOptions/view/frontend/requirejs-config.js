/**
* Copyright © 2016 ITORIS INC. All rights reserved.
* See license agreement for details
*/
var config = {
    map: {
        '*': {
            'itoris_options'  : 'Itoris_DynamicProductOptions/js/options'
        }
    }
    ,
    shim: {
        //"Itoris_DynamicProductOptions/js/options": ["prototype"]
    }

};